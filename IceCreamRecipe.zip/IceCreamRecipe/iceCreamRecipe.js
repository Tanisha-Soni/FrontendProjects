let IceCreams = document.querySelectorAll(".IceCreams");
let slider = document.getElementById("slider");

//initial loading changes
let prevSlide = document.getElementById(`slide0`);
prevSlide.style.filter = `blur(0px)`;
prevSlide.style.transform = `translateY(150px) scale(1.7)`;
let prevbg = document.getElementById("bg0");
prevbg.style.transform = `rotate(-45deg) scale(8) translateY(-30px) translateX(15px)`;
prevbg.style.opacity = `100%`;



let count = 0;
IceCreams.forEach(img => {
    img.addEventListener("click", function(){
        let currentId = this.id;
        let currentSlide = document.getElementById(`slide${currentId}`);
        
        //checking if the clicked image is enlarged already, so we need to go back to previous slide
        if((Boolean)(currentId > 0  & count==0  &   (currentSlide.id==prevSlide.id))){
            currentId -= 1;
            if(currentId<5){
                prevSlide = document.getElementById(`slide${currentId+1}`);
            }
            count++;
            console.log(`first count${count}` );
        }
        else if(currentId > 0 &  (currentSlide.id<prevSlide.id)){
            currentId -= 1;
            if(currentId<5){
                prevSlide = document.getElementById(`slide${currentId+1}`);
            }
            count++;
            console.log(`second count${count}`);
        }
        else if((Boolean)((currentSlide.id==prevSlide.id)) & currentId > 0){
            count = 0;
            prevSlide = document.getElementById(`slide${currentId-1}`);
            console.log(`third count${count}`);
        }

        let moveSlider = currentId * 400;
        change(moveSlider);
        changeBackground(currentId);
        changeSize(currentId, prevSlide);
        changeBgImg(currentId, prevSlide);
        changeContent(currentId);
        prevSlide = currentSlide;
    })
})

let contentSlider = document.getElementById("contentSlider");
function changeContent(currentId){
    contentSlider.style.transform = `translateY(-${currentId*300}px)`;
}


function changeSize(currentId , prevSlide){
    if(currentId != 0 & currentId<prevSlide.id){
        // prevSlide.style.transition = `opacity 0.2s transform 1s`;
        prevSlide.style.opacity = `0%`;
    }else{
        prevSlide.style.filter = `blur(2px)`;
    }
    prevSlide.style.transform = `translateY(0px) scale(1)`;
    let currentSlide = document.getElementById(`slide${currentId}`);
    currentSlide.style.filter = `blur(0px)`;
    currentSlide.style.opacity = `100%`;
    currentSlide.style.transform = `translateY(150px) scale(1.7)`;
}


function change(moveSlider){
    slider.style.transform = `translateX(-${moveSlider}px)`;
}


function changeBgImg(currentId, prevSlide){
    prevbg.style.transitionDelay =`0s`;
    prevbg.style.transform = `scale(1)`;
    prevbg.style.opacity = `0%`;
    let bgImage = document.getElementById(`bg${currentId}`);
    if(currentId%2==0){
        bgImage.style.transform = `rotate(-45deg) scale(8) translateY(-30px) translateX(15px) `;
    }
    else{
        bgImage.style.transform = `rotate(45deg) scale(8) translateY(-30px) translateX(-20px) `;
    }
    bgImage.style.opacity = `100%`;
    prevbg = bgImage;
}

let bgColours = ["#618faf, #476f89 ,#142535",
                 "#f198aa, #e8738e ,#cf005d",
                 "#544944, #2d2e33, #191a1e",
                 "#fddde2,#f198aa, #f198aa",
                 "#655241, #413831, #11100e",
                 "#f6feaa, #36e063, #39c741"];


function changeBackground(currentId){
    document.body.style.backgroundImage = `radial-gradient(${bgColours[currentId]})`;
}

// if(currentId!=0 & currentSlide!=prevSlide){
//     prevSlide.style.transition = `opacity 0.2s`;
//     prevSlide.style.opacity = `0%`;
//     prevSlide.style.transform =`translateY(0px) scale(1)`
//     let moveSlider = currentId * 400;
//     slider.style.transform = `translateX(-${moveSlider}px)`;
//     let bgImage = document.getElementById(`bg${currentId}`);
//     bgImage.style.opacity = `100%`;
//     bgImage.style.transform = `scale(8) translateY(10px) rotate(-45deg)`;
//     currentSlide.style.transform = `translateY(150px) scale(1.7)`;
// }
