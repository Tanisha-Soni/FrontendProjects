let player1 = document.getElementById("player1");
let player2 = document.getElementById("player2");
let playBtn = document.getElementById("playButton");
let result = document.getElementById("result");

playBtn.onclick = function(){
    let player1Dice = Math.floor(Math.random() * (7-1))+1;
    let player2Dice = Math.floor(Math.random() * (7-1))+1;

    player1.src = `/diceGame/diceImg/dice-${player1Dice}.png`;
    player2.src = `/diceGame/diceImg/dice-${player2Dice}.png`;

    if(player1Dice==player2Dice){
        result.textContent= "It's A TIE!!";
    }else if(player1Dice>player2Dice){
        result.textContent = "W PLAYER-1";
    }else{
        result.textContent = "W PLAYER-2";
    }
}