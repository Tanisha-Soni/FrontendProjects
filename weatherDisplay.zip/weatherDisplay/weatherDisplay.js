const button = document.getElementById("search");
const cityInput = document.getElementById("cityInput");

const showcity = document.getElementById("city");
const showCountry = document.getElementById("country");
const showTemp = document.getElementById("temp");


async function getData(location){
    const promise = await fetch(`http://api.weatherapi.com/v1/current.json?key=d98ace999cb3411d876181920241005&q=${location}&aqi=yes`);
    return await promise.json();
}

button.addEventListener('click', async () =>{
    const city = cityInput.value;
    const data = await getData(city);
    console.log(data);
    showcity.innerText = `City: ${data.location.name}`;
    showCountry.innerText = `Country: ${data.location.country}`;
    showTemp.innerText = `Temperature: ${data.current.temp_c} °C`;
})