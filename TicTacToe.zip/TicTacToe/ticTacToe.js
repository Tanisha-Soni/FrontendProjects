let currentPlayer = "X";
let arr = Array(9).fill(null);
let gameOver = false;

function textAppender(text){
    let wintext = document.createElement("h1");
    wintext.classList.add("title");
    wintext.innerText = text;
    document.body.append(wintext);
    gameOver = true;
}

function checkWinner(arr){
    console.log("check");
    console.log(arr);
    if(
        (arr[0] != null && (arr[0] == arr[1] && arr[1] == arr[2])) ||
        (arr[3] != null && (arr[3] == arr[4] && arr[4] == arr[5])) ||
        (arr[6] != null && (arr[6] == arr[7] && arr[7] == arr[8])) ||
        (arr[6] != null && (arr[6] == arr[3] && arr[3] == arr[0])) ||
        (arr[7] != null && (arr[7] == arr[4] && arr[4] == arr[1])) ||
        (arr[8] != null && (arr[8] == arr[5] && arr[5] == arr[2])) ||
        (arr[6] != null && (arr[6] == arr[4] && arr[4] == arr[2])) ||
        (arr[8] != null && (arr[8] == arr[4] && arr[4] == arr[0]))
    ){
        let winner = (currentPlayer == "X") ? 1 : 2;
        
        let text = `Player ${winner} Won!!`;
        textAppender(text);
        
    }
    else{
        if(!arr.includes(null)){
            let text = `DRAW!!!`;
            textAppender(text);
        }
    }
}

let display = (box) => {
    let currBox = Number(box.id);
    if(arr[currBox]!=null || gameOver==true) return;
    arr[currBox] = currentPlayer;
    box.innerHTML = currentPlayer;
    checkWinner(arr);
    box.style.backgroundColor = currentPlayer == "X" ? "#FFE6E6" :"#E1AFD1";
    currentPlayer = currentPlayer == "X" ? "O" :"X";
}