const logos = document.querySelectorAll('.logos');
const rotator = document.getElementById("rotator");


let lastClickedImgId = 1;
let prevImg = document.getElementById("img1");
prevImg.style.transform = `scale(2.5)`;
prevImg.style.transition = `all 1s`;


logos.forEach(img => {
    img.addEventListener('click', function() {
        prevImg.style.transform = `scale(1) rotate(-90deg)`;
        const clickedImgId = this.id;
        let rotation = clickedImgId - lastClickedImgId;
        rotator.style.transform = `rotate(${rotation * -60}deg)`;
        let currentImg = document.getElementById(`img${clickedImgId}`);
        currentImg.style.transition = `all 1s`;
        currentImg.style.transform = `scale(2.5) rotate(180deg)`;
        prevImg = currentImg;
    });
});