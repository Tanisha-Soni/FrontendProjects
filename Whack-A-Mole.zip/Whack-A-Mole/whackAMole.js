let score = document.getElementById("score");
let playBtn = document.getElementById("playBtn");
let ground = document.getElementById("ground");

let totalScore = 0;


let moleSpawn;
playBtn.onclick = function () {
    if (playBtn.innerHTML == "PLAY") {
        playBtn.innerHTML = "PAUSE"
        check = true;
        moleSpawn = setInterval(moleSpwanner, 2000);
    } else {
        playBtn.innerHTML = "PLAY"
        check = false;
        clearInterval(moleSpawn);
    }
}

function moleSpwanner() {
    let moleImage = document.createElement('img');
    moleImage.src = "Images/Mole.png";
    let randomRow = Math.floor(Math.random() * (4 - 1) + 1) + 1;
    let randomCol = Math.floor(Math.random() * (8 - 1) + 1) + 1;
    console.log(`row: ${randomRow}, col: ${randomCol}`);
    moleImage.style.gridRow = randomRow;
    moleImage.style.gridColumn = randomCol;
    moleImage.addEventListener("click", function () { ground.removeChild(moleImage); scoreUpdate(); });
    ground.appendChild(moleImage);

    setTimeout(function () { if (ground.children.length > 0) { ground.removeChild(moleImage); } }, 1500);
}

function scoreUpdate() {
    totalScore++;
    score.textContent = `Score: ${totalScore}`;
}